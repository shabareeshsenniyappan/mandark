import React from "react";

function Footer() {
  return (
    <div className="footer-hero-container">
      © BrandName. All rights reserved.
    </div>
  );
}

export default Footer;
