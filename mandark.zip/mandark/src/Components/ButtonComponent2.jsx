import React from "react";

function ButtonComponent2({ name }) {
  return <button className="button-styl2">{name}</button>;
}

export default ButtonComponent2;
