import React from "react";

function ButtonComponent({ name }) {
  return <button className="button-styl">{name}</button>;
}

export default ButtonComponent;
