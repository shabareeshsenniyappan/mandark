import React from "react";

function BoxComponent() {
  return <div className="box-container"></div>;
}

export default BoxComponent;
